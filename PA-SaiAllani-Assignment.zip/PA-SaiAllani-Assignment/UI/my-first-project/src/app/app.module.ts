import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { LogSummaryComponent } from './log-summary/log-summary.component';
import { LogDetailSearchComponent } from './log-detail-search/log-detail-search.component';

@NgModule({
  declarations: [
    AppComponent,
    LogSummaryComponent,
    LogDetailSearchComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
