import { Component, Input, OnInit } from '@angular/core';
import { LogService } from '../log-service.service';
import { LogDetail } from '../log-summary';

@Component({
  selector: 'app-log-detail-search',
  templateUrl: './log-detail-search.component.html',
  styleUrls: ['./log-detail-search.component.css']
})
export class LogDetailSearchComponent implements OnInit {
  logdetail : LogDetail = {
    id: '',
    requestTime: '',
    request: '',
    responseTime: '',
    response: '',
    duration: ''
  };
  constructor(public logService : LogService ) { }

  ngOnInit(): void {

  }

  searchClick(id: any)
  {
    if(id.value == '')
    {
      this.logdetail = this.logdetail;
      return;
    }
    this.logService.getLogDetail(id.value).subscribe((data: LogDetail)=>{
      this.logdetail = data;
      console.log(this.logdetail);
    })  
  }
}
