﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PA.SaiAllani.Utils
{
    public class ApplicationSettings
    {
        public string FileLogsFolderPath { get; set; }
    }
}
